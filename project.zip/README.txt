ECE353 Project

Jackson Melchert
Nick Cook
Team 33

Video = https://drive.google.com/file/d/0Bxhlu4LXcMeFLUlIYm9xQVR6YVE/view?usp=sharing